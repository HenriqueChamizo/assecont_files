use assecont2;

--declare @codigo_0 varchar(6) = @cli_des_codigo, 
--		@nome varchar(150) = @cli_des_nome, 
--		@tipo varchar(50) = @cli_des_tipo, 
--		@grupo varchar(50) = @cli_des_grupo 

--if exists(select cli_int_id from SealCliente where cli_des_codigo = @codigo_0)
--begin 
--	update SealCliente 
--	set cli_des_nome = @nome, 
--		cli_des_tipo = @tipo, 
--		cli_des_grupo = @grupo 
--	where cli_des_codigo = @codigo_0
--end else 
--begin
--	insert into SealCliente (cli_des_codigo, cli_des_nome, cli_des_tipo, cli_des_grupo) 
--	values (@codigo_0, @nome, @tipo, @grupo)
--end

--insert into SealCliente (cli_des_codigo, cli_des_grupo, cli_des_nome, cli_des_tipo) values 
--						('SEMDOC', 'DOCUMENTO N�O EXISTENTE', 'DOCUMENTO N�O EXISTENTE', 'Cliente')
--insert into SealDocumento (doc_des_descricao, doc_file_clientes, doc_file_contasreceber, doc_dt_data) 
--values ('DOCUMENTO N�O EXISTENTE', CONVERT(varbinary(max), 'DOCUMENTO N�O EXISTENTE'), CONVERT(varbinary(max), 'DOCUMENTO N�O EXISTENTE'), GETDATE())

--select * from SealCliente
--select * from SealDocumento

declare @codigo varchar(6) = @cli_des_codigo, 
		@doc int = @doc_int_id, 
		@cnpjorigem varchar(14) = @crb_des_cnpjorigem, 
		@docorigem int = @crb_int_docorigem, 
		@notafiscal varchar(20) = @crb_des_notafiscal, 
		@prest varchar(10) = @crb_des_prest, 
		@emissao datetime = @crb_dt_emissao, 
		@vencimento datetime = @crb_dt_vencimento, 
		@valor numeric(18, 6) = @crb_num_valor, 
		@desconto numeric(18, 6) = @crb_num_desconto, 
		@juros numeric(18, 6) = @crb_num_juros, 
		@valorrecebido numeric(18, 6) = @crb_num_valorrecebido, 
		@recebimento datetime = @crb_dt_recebimento, 
		@forma varchar(20) = @crb_des_forma, 
		@observacao varchar(250) = @crb_des_observacao 

if exists(select cli_int_id from SealCliente where cli_des_codigo = @codigo) 
begin 
	if not exists(select doc_int_id from SealDocumento where doc_int_id = @doc)
	begin
		set @doc = (select doc_int_id from SealDocumento where doc_des_descricao = 'DOCUMENTO N�O EXISTENTE')
	end
end else
begin
	if not exists(select doc_int_id from SealDocumento where doc_int_id = @doc)
	begin
		set @codigo = (select cli_int_id from SealCliente where cli_des_nome = 'DOCUMENTO N�O EXISTENTE')
		set @doc = (select doc_int_id from SealDocumento where doc_des_descricao = 'DOCUMENTO N�O EXISTENTE')
	end else
	begin 
		set @codigo = (select cli_int_id from SealCliente where cli_des_nome = 'CLIENTE N�O EXISTENTE')
	end
end

insert into SealContaReceber (cli_des_codigo, crb_des_cnpjorigem, crb_int_docorigem, crb_des_notafiscal, crb_des_prest, crb_dt_emissao, 
								crb_dt_vencimento, crb_num_valor, crb_num_desconto, crb_num_juros, crb_num_valorrecebido, crb_dt_recebimento, 
								crb_des_forma, crb_des_observacao, doc_int_id) values 
(@codigo, @cnpjorigem, @docorigem, @notafiscal, @prest, @emissao, @vencimento, @valor, @desconto, @juros, @valorrecebido, @recebimento, 
	@forma, @observacao, @doc)